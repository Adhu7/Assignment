package string;

public class Contains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String name="what do you know about me";
System.out.println(name.contains("do you know"));
System.out.println(name.contains("about"));
System.out.println(name.contains("hello"));
	}

}
