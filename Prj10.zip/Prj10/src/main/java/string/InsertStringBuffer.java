package string;

public class InsertStringBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer sb=new StringBuffer("Hello ");
sb.insert(1,"java");
System.out.println(sb);
	}

}
