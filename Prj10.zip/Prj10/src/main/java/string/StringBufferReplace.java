package string;

public class StringBufferReplace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer sb=new StringBuffer("Hello");
sb.replace(1, 3, "php");
System.out.println(sb);
	}

}
