package string;

public class EndsWith2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Welcome to stepskochi.com";
System.out.println(str.endsWith("kochi"));
if (str.endsWith(".com")) {
	System.out.println("String ends with.com");
	
}else System.out.println("It does not end with .com");
	}

}
