package string;



public class CharAt2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Welcome to steps kochi";
int count=0;
for (int i = 0; i <str.length()-1; i++) {
	if (str.charAt(i)=='e') {
		count++;
	}
}
System.out.println("Frequency of t is: "+count);
	}

}
