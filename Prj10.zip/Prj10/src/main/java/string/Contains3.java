package string;

public class Contains3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="To learn java visit stepskochi.com";
	if(str.contains("stepskochi")) {
		System.out.println("This string contains stepskochi.com");
	}else {
		System.out.println("Result not found");
	}
	}

}
