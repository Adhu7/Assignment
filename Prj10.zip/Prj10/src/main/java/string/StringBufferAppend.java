package string;

public class StringBufferAppend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer sb=new StringBuffer("Hello");
sb.append(" java");
System.out.println(sb);
	}

}
