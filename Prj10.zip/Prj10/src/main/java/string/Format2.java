package string;

public class Format2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1=String.format("%d",200 );
String str2=String.format("%s", "Amar Singh");
String str3=String.format("%f", 200.00);
String str4=String.format("%x", 101);
String str5=String.format("%c",'d');
System.out.println(str1);
System.out.println(str2);
System.out.println(str3);
System.out.println(str4);
System.out.println(str5);

	}

}
