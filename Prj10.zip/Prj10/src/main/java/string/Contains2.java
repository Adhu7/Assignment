package string;

public class Contains2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Hello Steps Kochi readers";
boolean isContains= str.contains("Steps");
System.out.println(isContains);
System.out.println("steps");
	}

}
