package string;

public class Concat2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1="Hello";
String str2="Steps";
String str3="Kochi";
String str4= str1.concat(str2);
System.out.println(str4);
String str5= str1.concat(" ").concat(str2).concat(" ").concat(str3);
System.out.println(str5);
String str6 =str1.concat("@").concat(str2);
System.out.println(str6);
	}

}
