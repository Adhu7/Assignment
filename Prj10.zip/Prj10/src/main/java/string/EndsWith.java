package string;

public class EndsWith {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="java by stepskochi";
System.out.println(s1.endsWith("h"));
System.out.println(s1.endsWith("steps"));

	}

}
