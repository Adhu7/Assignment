package string;

public class StringBufferReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer sb=new StringBuffer("Hello");
sb.reverse();
System.out.println(sb);
	}

}
