package pj;

public class Instanceof {
}
