package pj;

public class Leftshift {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(10<<2);
System.out.println(10<<3);
System.out.println(20<<2);
System.out.println(15<<4);
	}

}
