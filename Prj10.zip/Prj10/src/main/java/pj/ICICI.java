package pj;

public class ICICI extends Bank {
float getRateOfInterest() {return 7.3f;}
}
