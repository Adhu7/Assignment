package pj;

public class Shift {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(20>>2);
System.out.println(20>>>2);
System.out.println(-20>>2);
System.out.println(-20>>>2);
	}

}
