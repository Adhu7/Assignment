package pj;

public class AXIS extends Bank{
float getRateOfInterest() {return 9.7f;}
}
