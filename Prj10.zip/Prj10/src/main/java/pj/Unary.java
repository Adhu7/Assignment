package pj;

public class Unary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=10;
System.out.println(x++);//10 (11)
System.out.println(++x);//12
System.out.println(x--);//12 (11)
System.out.println(--x);//10
	
	}

}
