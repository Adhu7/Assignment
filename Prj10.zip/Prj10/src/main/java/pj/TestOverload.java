package pj;

public class TestOverload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(Overloading.add(10, 20));
System.out.println(Overloading.add(1.2, 5.3));
	}

}
