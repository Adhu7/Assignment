package pj;

public class Dog1 extends Instanceof {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Dog1 d= new Dog1();
System.out.println(d instanceof Instanceof);
	}

}
