package pj;

public class Bank {
float getRateOfInterest() {return 0;}
}
