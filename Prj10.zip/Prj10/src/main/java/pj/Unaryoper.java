package pj;

public class Unaryoper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
int b=10;
boolean c=true;
boolean d=false;
System.out.println(~a);
System.out.println(~~b);
System.out.println(!c);
System.out.println(!d);
	}

}
