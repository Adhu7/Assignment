package pj;

public class TestStaticStudent1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentStatic1.change();
		StudentStatic1 s1= new StudentStatic1(111,"Karan");
		StudentStatic1 s2= new StudentStatic1(112,"Aryan");
		StudentStatic1 s3= new StudentStatic1(113,"Sonoo");
		s1.display();
		s2.display();
		s3.display();
	}

}
