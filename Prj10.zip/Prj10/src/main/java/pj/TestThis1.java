package pj;

public class TestThis1 {

	public static void main(String args[]) {
		// TODO Auto-generated method stub
		ThisVariable s1=new ThisVariable(111,"Ankit",5000f);
		ThisVariable s2=new ThisVariable(112,"sumit",6000f);
		s1.display();
		s2.display();
	}

}
