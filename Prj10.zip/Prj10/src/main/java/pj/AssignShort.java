package pj;

public class AssignShort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
short a=10;
short b=10;
a=(short)(a+b);
System.out.println(a);
	}

}
