package pj;

public class Overriding1 {
	void run() {
		System.out.println("Runnng");
	}

}
