package pj;

import java.util.Scanner;

public class Employee {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Name");
		String name = scanner.nextLine();
				System.out.println("Gender as F/M");
		char gender = scanner.next().charAt(0);
		System.out.println("Age");
		int age = scanner.nextInt();
		System.out.println("Mobile");
		long mobileNo = scanner.nextLong();
		System.out.println("Expected CGPA");
		double cgpa = scanner.nextDouble();
		System.out.println("Name: " + name);
		System.out.println("Gender: " + gender);
		System.out.println("Age: " + age);
		System.out.println("Mobile: " + mobileNo);
		System.out.println("CGPA: " + cgpa);
		
	}

}
