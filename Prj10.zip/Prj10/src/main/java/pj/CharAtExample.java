package pj;

public class CharAtExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String name="Welcome to steps";
char ch=name.charAt(16);
System.out.println(ch);
	}

}
