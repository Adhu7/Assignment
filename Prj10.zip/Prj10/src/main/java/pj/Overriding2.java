package pj;

public class Overriding2 extends Overriding1 {
	void running() {
		System.out.println("Running");
	}
	void run() {
		System.out.println("Man Running...");
	}
}
