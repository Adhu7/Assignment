package pj;

public class ThisVariable {
	int rollno;
	String name;
	float fee;
	ThisVariable(int r,String n,float f){
	rollno=r;
	name=n;
	fee=f;
}
void display() {System.out.println(rollno+" "+name+" "+fee);}
}

	
