package pj;

public class Or {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
int b=5;
int c=20;
System.out.println(a>b||a<c);
System.out.println(a>b|a<c);
System.out.println(a>b||a++<c);
System.out.println(a);
System.out.println(a>b|a++<c);
System.out.println(a);
	}

}
