package pj;

public class Overriding3 extends Overriding2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overriding2 over=new Overriding2();
		over.run();
		over.running();
	}

}
