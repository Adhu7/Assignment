package pj;

public class Ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int number=13;
if (number%2==0) {
	System.out.println("even number");
	
}else {
	System.out.println("odd number");
}
	}

}
