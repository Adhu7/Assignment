package pj;

public class StudentStatic1 {
int rollno;
String name;
static String college = "ITS";
 static void change() {
	college= "BBDIT";
}
StudentStatic1(int r, String n){
	rollno= r;
	name= n;
}
void display() {System.out.println(rollno+" "+name+" "+college);}

}
