package pj;

public class SBI extends Bank{
float getRateOfInterest() {return 8.4f;}
}
