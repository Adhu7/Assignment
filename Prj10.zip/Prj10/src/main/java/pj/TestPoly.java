package pj;

public class TestPoly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bank b;
b=new SBI();
System.out.println("SBI Rate Of Interest: " +b.getRateOfInterest());
b= new ICICI();
System.out.println("ICICI Rate Of Interest: " +b.getRateOfInterest());
b=new AXIS();
System.out.println("AXIX Rate Of Interest: " +b.getRateOfInterest());
	}

}
