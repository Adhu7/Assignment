package assignment;

public  class MyClass implements A {
 public void meth1() {System.out.println("Meth1");}
 public void meth2() {System.out.println("Meth2");}

public static void main(String[] args) {
	// TODO Auto-generated method stub
MyClass mc=new MyClass();
mc.meth1();
mc.meth2();
}
}