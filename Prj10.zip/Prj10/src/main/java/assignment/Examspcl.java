package assignment;

public class Examspcl {
	public static void main(String[] args) {
		Exam exam1=new Exam();
		Exam exam2=new Exam();
		exam2.setName("Athul");
		exam2.setAge(20);
		System.out.println(exam2.getName());
		System.out.println(exam2.getAge());
	}
}
