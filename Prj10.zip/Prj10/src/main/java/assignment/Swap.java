package assignment;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num1=25;
int num2=30;
int temp= num1;
num1=num2;
num2=temp;
System.out.println("Now first number: "+num1);
System.out.println("Now second number: "+num2);
	}

}
