package assignment;

public class AccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Account acc=new Account(500.0);

System.out.println("Initial balance: "+acc.getBalance());

	}

}
