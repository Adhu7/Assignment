package assignment;

public class Multiple3 extends Multiple,Multiple2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Multiple3 obj=new Multiple3();
obj.msg();
	}

}
