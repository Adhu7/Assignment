package assignment;

public class Multiple2 {
void msg() {System.out.println("Welcome");}
}
