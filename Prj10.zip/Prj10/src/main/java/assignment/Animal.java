package assignment;

public class Animal {

}
