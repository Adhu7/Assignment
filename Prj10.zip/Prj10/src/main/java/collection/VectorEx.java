package collection;

import java.util.Iterator;
import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vector<String> v=new Vector<String>();
v.add("Ayush");
v.add("Sanjay");
v.add("Amit");
v.add("Nikhil");
Iterator<String> itr=v.iterator();
while (itr.hasNext()) {
	System.out.println(itr.next());
}
	}

}
