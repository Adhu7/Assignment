package collection;

import java.util.Iterator;
import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Stack<String> stack=new Stack<String>();
stack.push("Ayush");
stack.push("Sanjay");
stack.push("Ashwin");
stack.push("Abi");
stack.pop();
Iterator<String> itr=stack.iterator();
while (itr.hasNext()) {
	System.out.println(itr.next());
}
	}

}
