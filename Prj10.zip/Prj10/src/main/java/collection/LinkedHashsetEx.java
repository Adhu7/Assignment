package collection;
import java.util.*;
public class LinkedHashsetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LinkedHashSet<String> set=new LinkedHashSet<String>();
set.add("Sachin");
set.add("Rohit");
set.add("Sanju");
set.add("Sachin");
Iterator<String> itr=set.iterator();
while (itr.hasNext()) {
	System.out.println(itr.next());
}
	}

}
