package collection;
import java.util.*;
public class HashsetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashSet<String> set=new HashSet<String>();
set.add("Sachin");
set.add("Rohit");
set.add("Sanju");
set.add("Sachin");
Iterator<String> itr=set.iterator();
while (itr.hasNext()) {
	System.out.println(itr.next());
}
	}

}
