package collection;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeueEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Deque<String> deque=new ArrayDeque<String>();
deque.add("Sachin");
deque.add("Rohit");
deque.add("Sanju");
for (String string : deque) {
	System.out.println(string);
}
	}

}
