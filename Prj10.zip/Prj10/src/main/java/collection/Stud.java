package collection;

public class Stud {
int rollno;
String name;
int age;
public Stud(int rollno, String name, int age) {
	super();
	this.rollno = rollno;
	this.name = name;
	this.age = age;
}

}
