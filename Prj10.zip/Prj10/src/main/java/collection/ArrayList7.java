package collection;
import java.io.*;
import java.util.*;
public class ArrayList7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> al=new ArrayList<String>();
al.add("Ravi");
al.add("Vijay");
al.add("Ajay");

try {
	FileOutputStream fos=new FileOutputStream("file");
	ObjectOutputStream os=new ObjectOutputStream(fos);
	os.writeObject(al);
	fos.close();
	os.close();
	FileInputStream fis=new FileInputStream("file");
	ObjectInputStream ois=new ObjectInputStream(fis);
	ArrayList list=(ArrayList)ois.readObject();
	System.out.println(list);
} catch (Exception e) {
	// TODO: handle exception
	System.out.println(e);
	
}
	}

}
