package collection;

import java.util.HashMap;

class RemoveHashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashMap<Integer, String> languages=new HashMap<Integer, String>();
languages.put(1, "Java");
languages.put(2, "Python");
languages.put(3, "JavaScript");
System.out.println("HashMap: "+languages);

String value=languages.remove(2);
System.out.println("Updated HashMap: "+languages);
	}

}
