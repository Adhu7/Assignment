package collection;
import java.util.*;
public class TreesetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet<String> set=new TreeSet<String>();
set.add("Sachin");
set.add("Rohit");
set.add("Sachin");
set.add("Sanju");
Iterator<String> itr=set.iterator();
while (itr.hasNext()) {
	System.out.println(itr.next());
}
	}

}
