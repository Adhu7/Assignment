package collection;
import java.util.*;
public class ArrayListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> list=new ArrayList<String>();
list.add("Ravi");
list.add("vijay");
list.add("Ravi");
list.add("Ajay");
Iterator itr=list.iterator();
while (itr.hasNext()) {
	System.out.println(itr.next());
}
	}

}
