package collection;
import java.util.*;
public class ArrayList6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Stud s1=new Stud(101,"Sonoo",23); 
Stud s2=new Stud(102,"Ravi",21);
Stud s3=new Stud(103,"Virat",25);
ArrayList<Stud> al=new ArrayList<Stud>();
al.add(s1);
al.add(s2);
al.add(s3);
Iterator itr=al.iterator();
while (itr.hasNext()) {
	Stud st=(Stud)itr.next();
	System.out.println(st.rollno+" "+st.name+" "+st.age);
}
	}

}
