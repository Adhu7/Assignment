package collection;
import java.util.*;
public class ArrayList11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> al=new ArrayList<String>();
al.add("Ravi");
al.add("Viaj");
al.add("Ajay");
System.out.println("After insertion");
System.out.println("Is ArrayList is empty: "+al.isEmpty());
	}

}
