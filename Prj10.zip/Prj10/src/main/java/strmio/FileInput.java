package strmio;

import java.io.FileInputStream;
import java.io.IOException;

public class FileInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try (FileInputStream fis =new FileInputStream("testfile1.txt")) {
byte[] data =new byte[100];
int bytesRead = fis.read(data);

String content = new String(data, 0, bytesRead);
System.out.println("Data read from file: ");
System.out.println(content);
} catch (IOException e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
