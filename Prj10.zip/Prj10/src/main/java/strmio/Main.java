package strmio;

import java.io.FileOutputStream;
import java.io.OutputStream;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String data= "This is a line of text inside the file.";

try {
	OutputStream out =new FileOutputStream("testfile.txt");
	byte[]dataBytes = data.getBytes();
	out.write(dataBytes);
	System.out.println("Data is written to the file.");
	out.close();
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
