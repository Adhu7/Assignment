package strmio;

import java.io.Serializable;

public class Person1 implements Serializable {
private static final long serialVersionUID= 1L;
private String name;
private int age;


	public Person1(String name, int age) {
	super();
	this.name = name;
	this.age = age;
}

public String toString() {
	return "Person{" +
			 "name='" + name + '\'' +
			 ", age=" + age +
			 '}';
	

}
}