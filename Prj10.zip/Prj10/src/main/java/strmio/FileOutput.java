package strmio;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String content= "Hello, this file is a FileOutputStream example.";

try (FileOutputStream fos= new FileOutputStream("testfile1.txt")){
	byte[] bytes=content.getBytes();
	fos.write(bytes);
	System.out.println("Data has been written to the file 'testfile1.txt'.");
} catch (IOException e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
