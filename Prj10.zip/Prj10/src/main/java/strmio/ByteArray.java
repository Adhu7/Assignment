package strmio;

import java.io.ByteArrayInputStream;
import java.io.IOException;

public class ByteArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
byte[] data= "Hello, this is a ByteArrayInputStream example.".getBytes();

try (ByteArrayInputStream bais= new ByteArrayInputStream(data)) {
	byte[] buffer=new byte[100];
	int bytesRead = bais.read(buffer);
	String content = new String(buffer, 0, bytesRead);
	System.out.println("Data read from ByteArrayInputStream: ");
	System.out.println(content);
} catch (IOException e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
