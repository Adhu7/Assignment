package strmio;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ObjectOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Person1 person=new Person1("Alice", 30);
 
 try (FileOutputStream fos=new FileOutputStream("person.ser");
	ObjectOutputStream oos= new ObjectOutputStream(fos)	) {
	 oos.writeObject(person);
	 System.out.println("Person object has been written to person.ser.");
	
} catch (Exception e) {
	// TODO: handle exception
   e.printStackTrace();
}
	}

}
