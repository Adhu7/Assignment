package strmio;
import java.io.*;
public class Deserialize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try (FileInputStream fis= new FileInputStream("person.ser");
	ObjectInputStream ois=new ObjectInputStream(fis)) {
	
	Person person= (Person) ois.readObject();
	System.out.println("Deserialized Person Object: "+ person);
} catch (IOException | ClassNotFoundException e) {
	// TODO: handle exception
	e.printStackTrace();
} 
	}

}
