package strmio;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ByteOut {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String content= "Hello, this is a ByteArrayOutputStream example.";

try (ByteArrayOutputStream baos= new ByteArrayOutputStream()){
	byte[] bytes= content.getBytes();
	baos.write(bytes);
	
	byte[] data=baos.toByteArray();
	String retrievedData= new String(data);
	System.out.println("Data in ByteArrayOutoutStream: "+retrievedData);
	
} catch (IOException e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
