package strmio;
import java.io.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Person implements Serializable {
private String name;
private int age;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Person person = new Person("Alice", 30);
 try (FileOutputStream fos=new FileOutputStream("person.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos) ){
	oos.writeObject(person);
	System.out.println("Person object has been serialized to person.ser.");
} catch (Exception e) {
	// TODO: handle exception
	
}
	}


	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

}
