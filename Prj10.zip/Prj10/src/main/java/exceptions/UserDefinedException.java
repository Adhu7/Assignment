package exceptions;

public class UserDefinedException extends Exception {
public UserDefinedException(String str) {
	super(str);
}
}
