package exceptions;

import java.io.IOException;
import java.io.StringReader;

public class StringRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String data = "Hello, this is a StringReader example.";
try (StringReader reader=new StringReader(data)){
	char[] buffer= new char[1024];
	int charsRead;
	while ((charsRead= reader.read(buffer)) !=-1) {
		System.out.print(new String(buffer, 0, charsRead));
	}
} catch (IOException e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
