package exceptions;

import java.io.IOException;

public class N {
	void method()throws IOException{
		System.out.println("device operation performed");
	}

}
