package exceptions;

import java.io.IOException;

public class Throws4 {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
L l=new L();
l.method();
System.out.println("normal flow...");
	}

}
