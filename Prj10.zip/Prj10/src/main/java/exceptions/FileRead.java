package exceptions;

import java.io.FileReader;
import java.io.IOException;

public class FileRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try (FileReader reader=new FileReader("testfile.txt")) {
	int data;
	while ((data = reader.read()) !=-1) {
		char  character = (char) data;
		System.out.print(character);
	}
} catch (IOException e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}
