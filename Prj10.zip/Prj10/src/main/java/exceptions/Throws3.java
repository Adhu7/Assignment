package exceptions;

import java.io.IOException;

public class Throws3 {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
N n=new N();
n.method();

System.out.println("normal flow...");
	}

}
