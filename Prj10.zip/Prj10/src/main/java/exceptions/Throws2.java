package exceptions;

public class Throws2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	M m=new M();
	m.method();
} catch (Exception e) {
	// TODO: handle exception
	System.out.println("exception handled");
}
System.out.println("normal flow...");
	}

}
