package exceptions;

import java.io.IOException;

public class M {
	void method()throws IOException{
		throw new IOException("device error");
	}

}
