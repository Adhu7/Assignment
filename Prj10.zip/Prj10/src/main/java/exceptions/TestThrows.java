package exceptions;

import java.io.IOException;

public class TestThrows {
 void m()throws IOException{
	 throw new IOException("device eror");
 }
 
 void n()throws IOException{
	m();
 }
  void p() {
	  try {
		n();
	} catch (Exception e) {
		System.out.println("exception handled");
		// TODO: handle exception
	}
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
TestThrows obj=new TestThrows();
obj.p();
System.out.println("normal flow..");
	}

}
