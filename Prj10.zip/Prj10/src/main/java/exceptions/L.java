package exceptions;

import java.io.IOException;

public class L {
	void method()throws IOException{
		
		throw new IOException("device error");
	}

}
