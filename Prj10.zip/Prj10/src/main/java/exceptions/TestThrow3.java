package exceptions;

public class TestThrow3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	throw new UserDefinedException("This is user defined exception");
} catch (UserDefinedException ude) {
	// TODO: handle exception
	System.out.println("Caught the exception");
	System.out.println(ude.getMessage());
}
	}

}
