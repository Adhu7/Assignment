package files;

import java.io.File;
import java.io.FileNotFoundException;

import java.util.Scanner;

public class ReadFromFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	File f1=new File("D:FileOperationExample.txt");
	Scanner dataReader=new Scanner(f1);
	while (dataReader.hasNextLine()) {
		String fileData =  dataReader.nextLine();
		System.out.println(fileData);
		
	}
	dataReader.close();
} catch (FileNotFoundException e) {
	System.out.println("Unexpected error occured!");
	e.printStackTrace();
	// TODO: handle exception
}
	}

}
