package files;

class NamingThread extends Thread {
	public void run() {
		System.out.println("running..");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NamingThread namingThread1=new NamingThread();
		NamingThread namingThread2= new NamingThread();
		
		System.out.println("name of namingThread1:"+namingThread1.getName());
		System.out.println("name of namingThread2:"+namingThread2.getName());
		
		namingThread1.start();
		namingThread2.start();
		
		namingThread1.setName("Athul");
		System.out.println("After changing the name:"+namingThread1.getName());
	}

}
