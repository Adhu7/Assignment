package files;

import java.io.File;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	File f0=new File("D:FileOperationExample.txt");
	if (f0.createNewFile()) {
		System.out.println("File " + f0.getName() + "is create d successfully.");
	} else {
		System.out.println("File is already exist in the directory.");

	}
	
} catch (IOException e) {
	System.out.println("An unexpected error is occured.");
	e.printStackTrace();
	// TODO: handle exception
}
	}

}
