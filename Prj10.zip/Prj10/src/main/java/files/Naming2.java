package files;

public class Naming2 extends Thread {
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Naming2 t1=new Naming2();
Naming2 t2= new Naming2();

t1.start();
t2.start();
	}

}
