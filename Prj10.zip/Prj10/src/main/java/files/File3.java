package files;

import java.io.File;

public class File3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File f=new File("/Users/Adhu/Downloads");
String filenames[]=f.list();
for (String filename : filenames) {
	System.out.println(filename);
}
	}

}
