package files;

import java.io.File;

public class File4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File dir=new File("/Users/Adhu/Documents");
File files[]=dir.listFiles();
for (File file : files) {
	System.out.println(file.getName()+" Can write: "+ file.canWrite()+ "Is Hiddrn: "+file.isHidden()+" length: "+file.length()+" bytes");
}
	}

}
