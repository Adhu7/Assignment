package files;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	FileWriter fwrite=new FileWriter("D:FileOperationExample.txt");
	fwrite.write("A named location used to store related infomartion is refered to as a File.");
	fwrite.close();
	System.out.println("Content is suucessfully wrote to  the file.");
} catch (IOException e) {
	System.out.println("Unexpected error occured");
	e.printStackTrace();
	// TODO: handle exception
}
	}

}
