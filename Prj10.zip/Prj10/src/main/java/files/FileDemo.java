package files;
import java.io.*;
public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	File file =new File("javaFile123.txt");
	if (file.createNewFile()) {
		System.out.println("New file is created!");
		
	} else {
		System.out.println("File already exixts.");

	}
	
	
} catch (IOException e) {
	e.printStackTrace();
	// TODO: handle exception
}
	}

}
