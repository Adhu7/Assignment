package assignment;

public interface Test {
int square(int a);
}
