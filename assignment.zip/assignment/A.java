package assignment;

public interface A {
void meth1();
void meth2();

}
