package assignment;

public class ToTestInt extends Arithemetics{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Arithemetics art=new Arithemetics();
art.square(5);

//System.out.println(ar.square(5));
	}

}
