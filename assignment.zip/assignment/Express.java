package assignment;

public class Express {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double express1= 25.5*3.5-3.5*3.5;
double express2= 40.5-4.5;
double result= express1/express2;
System.out.println(result);
	}

}
