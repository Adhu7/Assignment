package assignment;

public class Multiple {
void msg() {System.out.println("Hello");}
}
