package assignment;

public class Formula {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double result= 4.0*(1-(1.0/3)+ (1.0/5) - (1.0/7) + (1.0/9)-(1.0/11));
System.out.println(result);
	}

}
